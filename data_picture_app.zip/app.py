from flask import Flask, render_template, request, redirect, url_for, flash, send_from_directory
from werkzeug.utils import secure_filename
import sqlite3
from pathlib import Path
import uuid

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "app.db"
UPLOAD_DIR = BASE_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "webp"}

app = Flask(__name__)
app.secret_key = "change-this-secret-key"

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            image TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route("/")
def index():
    conn = db()
    records = conn.execute("SELECT * FROM records ORDER BY id DESC").fetchall()
    conn.close()
    return render_template("index.html", records=records)

@app.route("/add", methods=["POST"])
def add_record():
    title = request.form.get("title", "").strip()
    description = request.form.get("description", "").strip()
    image_file = request.files.get("image")

    if not title:
        flash("Title is required.")
        return redirect(url_for("index"))

    image_name = None
    if image_file and image_file.filename:
        if not allowed_file(image_file.filename):
            flash("Allowed images: PNG, JPG, JPEG, GIF, WEBP.")
            return redirect(url_for("index"))

        ext = secure_filename(image_file.filename).rsplit(".", 1)[1].lower()
        image_name = f"{uuid.uuid4().hex}.{ext}"
        image_file.save(UPLOAD_DIR / image_name)

    conn = db()
    conn.execute(
        "INSERT INTO records (title, description, image) VALUES (?, ?, ?)",
        (title, description, image_name)
    )
    conn.commit()
    conn.close()

    flash("Record saved successfully.")
    return redirect(url_for("index"))

@app.route("/delete/<int:record_id>", methods=["POST"])
def delete_record(record_id):
    conn = db()
    record = conn.execute("SELECT image FROM records WHERE id = ?", (record_id,)).fetchone()
    conn.execute("DELETE FROM records WHERE id = ?", (record_id,))
    conn.commit()
    conn.close()

    if record and record["image"]:
        image_path = UPLOAD_DIR / record["image"]
        if image_path.exists():
            image_path.unlink()

    flash("Record deleted.")
    return redirect(url_for("index"))

@app.route("/uploads/<filename>")
def uploaded_file(filename):
    return send_from_directory(UPLOAD_DIR, filename)

if __name__ == "__main__":
    init_db()
    app.run(debug=True, host="127.0.0.1", port=5000)
