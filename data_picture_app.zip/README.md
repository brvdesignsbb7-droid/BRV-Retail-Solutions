# Data & Picture App

A simple local web app for saving data and uploading pictures.

## Features

- Save title and description
- Upload PNG, JPG, JPEG, GIF, or WEBP pictures
- Store records in SQLite
- View uploaded pictures
- Delete records
- Runs locally on Windows, macOS, or Linux

## Install

1. Install Python 3.10 or newer.
2. Open a terminal inside this project folder.
3. Run:

```bash
python -m venv venv
```

### Windows

```bash
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

### macOS/Linux

```bash
source venv/bin/activate
pip install -r requirements.txt
python app.py
```

4. Open this address in your browser:

http://127.0.0.1:5000

## Data location

- `app.db` = saved data
- `uploads/` = uploaded pictures

## Important

This starter app is intended for local use. Before putting it online, add authentication, secure secret configuration, file-size limits, stronger file validation, backups, and production deployment settings.
